<?php 
include "koneksi.php";
	session_start();
	if(!isset($_SESSION['username'])){
		header("location:../login.php");
	}
	
$sql=mysqli_query($koneksi,"SELECT * FROM tb_produk WHERE id_produk='".$_GET['id_produk']."'");
$r=mysqli_fetch_array($sql);
?>
<center>
	<h2>Edit Data</h2>
	<form method="POST" action="" enctype="multipart/form-data">
		<table border="3">
			<tr>
				<td>Masukkan Nama Produk</td>
				<td>:</td>
				<td><input type="text" name="produk" value="<?php echo $r['produk'] ?>"></td>
			</tr>
			<tr>
				<td>Masukkan tgl_post</td>
				<td>:</td>
				<td><input type="date" name="tgl_post" value="<?php echo $r['tgl_post'] ?>"></td>
			</tr>
			<tr>
				<td>Deskripsi</td>
				<td>:</td>
				<td><textarea name="deskripsi"><?php echo $r['deskripsi']; ?></textarea></td>
			</tr>
			<tr>
				<td>Masukkan Gambar</td>
				<td>:</td>
				<td><input type="file" name="foto"></td>
			</tr>
			<tr>
				<td colspan="3"><center><img src="img/<?php echo $r['foto']; ?>" width="100" height="100"></center></td>
			</tr>
			<tr><td colspan="3"><center><input type="submit" name="update" value="Update"></center></td></tr>
		</table>
	</form>
</center>

<?php 
if (isset($_POST['update'])) {
 	$foto=$_FILES['foto']['name'];
 	$source=$_FILES['foto']['tmp_name'];
 	$folder='./foto/';

 	if ($foto !='') {
 		move_uploaded_file($source, $folder.$foto);
 		$sql=mysqli_query($koneksi,"UPDATE tb_produk SET produk='".$_POST['produk']."',tgl_post='".$_POST['tgl_post']."',deskripsi='".$_POST['deskripsi']."',foto='".$foto."' WHERE id_produk='".$_GET['id_produk']."'");
 	}
 	else{
 		$sql=mysqli_query($koneksi,"UPDATE tb_produk SET produk='".$_POST['produk']."',tgl_post='".$_POST['tgl_post']."',deskripsi='".$_POST['deskripsi']."' WHERE id_produk='".$_GET['id_produk']."'");
 	}
 	if ($sql) {
 		echo "Berhasil";
 		header("location:index.php");
 	}
 	else{
 		echo "Gagal";
 	}
 } 
 ?>