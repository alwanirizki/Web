<?php include "koneksi.php";
	session_start();
	if(!isset($_SESSION['username'])){
		header("location:../login.php");
	}
$delete=mysqli_query($koneksi, "DELETE FROM tb_produk WHERE id_produk='".$_GET['id_produk']."'");
if ($delete) {
	echo "<script>alert('Anda Yakin Untuk Menghapus Data Ini?')</script>";
	echo "<script>location='index.php'</script>";
}
else{
	echo "Gagal";
} ?>