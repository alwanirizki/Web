<?php 
	include "koneksi.php"; 
	session_start();
	if(!isset($_SESSION['username'])){
		header("location:../login.php");
	}
?>
<center>
	<h2>Data Produk</h2>
	<a href="input.php">Input Data</a> ||
	<a href="../logout.php">Logout</a>
	<table border="4">
		<tr>
			<td>No</td>
			<td>Produk</td>
			<td>Tanggal Post</td>
			<td>Deskripsi</td>
			<td>Gambar</td>
			<td>Opsi</td>
<?php 
$no=1;
$sql=mysqli_query($koneksi,"SELECT * FROM tb_produk");
while ($r=mysqli_fetch_array($sql)) { ?>
	<tr>
		<td><?php echo $no++; ?></td>
		<td><?php echo $r['produk']; ?></td>
		<td><?php echo $r['tgl_post']; ?></td>
		<td><?php echo $r['deskripsi']; ?></td>
		<td><img src="img/<?php echo $r['foto']; ?>" width=100></td>
		<td>
			<a href="edit.php?id_produk=<?php echo $r['id_produk']; ?>">Edit</a>||
			<a href="hapus.php?id_produk=<?php echo $r['id_produk']; ?>">Hapus</a>
		</td>
	</tr>
<?php }
 ?>


		</tr>
	</table>
</center>