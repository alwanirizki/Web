<?php 
include "koneksi.php"; 
	session_start();
	if(!isset($_SESSION['username'])){
		header("location:../login.php");
	}
?>
<center>
	<h2>Input Data</h2>
	<form method="POST" action="" enctype="multipart/form-data">
		<table border="3">
			<tr>
				<td>Masukkan Nama Produk</td>
				<td>:</td>
				<td><input type="text" name="produk"></td>
			</tr>
			<tr>
				<td>Masukkan Tanggal Post</td>
				<td>:</td>
				<td><input type="date" name="tgl_post"></td>
			</tr>
			<tr>
				<td>Masukkan Deskripsi</td>
				<td>:</td>
				<td><textarea name="deskripsi"></textarea></td>
			</tr>
			<tr>
				<td>Masukkan Gambar</td>
				<td>:</td>
				<td><input type="file" name="foto"></td>
			</tr>
			<tr>
				<td colspan="3"><center><input type="submit" name="simpan" value="Simpan"></center></td>
			</tr>
		</table>
	</form>
</center>
<?php 
	if(isset($_POST['simpan'])){
		$foto=$_FILES['foto']['name'];
		$source=$_FILES['foto']['tmp_name'];
		$folder='./img/';

		move_uploaded_file($source, $folder.$foto);
		$sql=mysqli_query($koneksi,"INSERT INTO tb_produk VALUES (NULL,'".$_POST['produk']."','".$_POST['tgl_post']."','".$_POST['deskripsi']."','".$foto."')");
		if($sql){
			echo "<script>alert('data berhasil disimpan')</script>";
			echo "<script>location='index.php';</script>";
		}
		else{
			echo "<script>alert('data gagal disimpan')</script>";
		}
	}

 ?>