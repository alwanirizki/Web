<!DOCTYPE html>
<html>
  <head>
    <title>Hasa Store</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  </head>

    <body>
<div class="navbar-fixed">
  <nav class="teal nav-extended">
    <div class="nav-wrapper container">
      <a href="index.php?p=home" class="brand-logo">Hasa Store</a>
      <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="index.php?p=home">Home</a></li>
        <li><a href="index.php?p=produk">Produk</a></li>
        <li><a href="index.php?p=gallery">Gallery</a></li>
        <li><a href="index.php?p=contact">Contact</a></li>
      </ul>
    </div>
  </nav>
</div>
  <ul class="sidenav" id="mobile-demo">
    <li><a href="index.php?p=home">Home</a></li>
    <li><a href="index.php?p=produk">Produk</a></li>
    <li><a href="index.php?p=gallery">Gallery</a></li>
    <li><a href="index.php?p=contact">Contact</a></li>
  </ul>

<?php 
  if(@$_GET['p']==""){
    include_once 'page/home.php';
  }
  elseif(@$_GET['p']=="home"){
    include_once 'page/home.php';
  }
  elseif(@$_GET['p']=="produk"){
    include_once 'page/produk.php';
  }
  elseif(@$_GET['p']=="gallery"){
    include_once 'page/gallery.php';
  }
  elseif(@$_GET['p']=="contact"){
    include_once 'page/contact.php';
  }

 ?>
 
  <footer class="page-footer white darken-4 white-text">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="light">CONTACT</h5>
                <ul>
                  <p><a href="#!"><i class="material-icons white-text">email</i></a> rizkialwani2710@gmail.com</p>
                  <p><a href="#!"><i class="material-icons white-text">instagram</i></a> rizkialwani_</p>
                   <p><a href="#!"><i class="material-icons white-text">store_mall_directory</i></a>  Koto Panjang Pyobasung, Payakumbauh Timur</p>
                  <p><a href="#!"><i class="material-icons white-text">whatsapp</i></a> 081363115060</p>
                </ul>
              </div>
  <footer class="page-footer teal">
    <div class="footer-copyright container">
    | © 2018 Copyright Rizki Alwani |
    </div>
  </footer>

    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script type="text/javascript">
      const sidenav = document.querySelector('.sidenav');
      M.Sidenav.init(sidenav);

      const slider = document.querySelector('.slider');
      M.Slider.init(slider, {
          indicators: false,
          height: 500,
          transition: 900,
          interval: 3000        
      });

      const materialbox = document.querySelectorAll('.materialboxed');
      M.Materialbox.init(materialbox);
    </script>
  </body>
</html>