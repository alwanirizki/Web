<tr class="red-text">
			<td><h4>E-mail</h4></td>
			<td><h4>:</h4></td>
			<td><h4>rizkialwani2710@gmail.com</h4></td>
		</tr>

		<tr class="green-text">
			<td><h4>WhatsApp</h4></td>
			<td><h4>:</h4></td>
			<td><h4>+62 813 6311 5060</h4></td>
		</tr>

		<tr class="purple-text">
			<td><h4>Instagram</h4></td>
			<td><h4>:</h4></td>
			<td><h4>@rizkialwani_</h4></td>
		</tr>