<div class="container">
	<h3 class="center teal-text">Contact</h3>
	<div class="progress"><div style="width: 100%" class="determinate"></div></div>
	<table>
		
		 <section>
    <div id="contact" class="contact grey lighten-3 scrollspy">
      <div class="container">
        <h3 class="wow bounceInDown light grey-text text-darken-3 center" data-wow-delay="1s">Contact Us</h3>
        <div class="row">
          <div class="wow zoomIn col m5 s12" data-wow-delay="1.8s">
            <div class="card-panel cyan accent-4 center white-text">
              <i class="material-icons">email</i>
              <h5>Contact Us</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.
              </p>
            </div>
            <ul class="collection width-header">
              <li class="collection-header light "><h4>Our Office</h4></li>
              <li class="collection-item">Recomanded Web</li>
              <li class="collection-item">Koto Panjang Payobasung, Payakumbuh Timur</li>
              <li class="collection-item">West Sumatra, indonesia</li>
            </ul>
          </div>


           <div class="wow zoomIn col m7 s12" data-wow-delay="2.4s">
          <form>
            <div class="card-panel light ">
              <h5>Please Fill this form</h5>
              <div class="input-field">
                <input type="text" name="name" id="name" required="" >
                <label for="name">Name</label>
              </div>
              <div class="input-field">
                <input type="email" name="email" id="email" class="valide">
                <label for="email">Email</label>
              </div>
              <div class="input-field">
                <input type="text" name="phone" id="phone">
                <label for="phone">Phone Number</label>
              </div>
              <div class="input-field">
               <textarea name="message" id="message" class="materialize-textarea"></textarea>
                <label for="message">message</label>
              </div>
              <button type="submit" class="btn cyan accent-4 ">Send</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
	</table>
</div>