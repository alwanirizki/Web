  <div class="slider">
    <ul class="slides">
      <li>
        <img class="responsive-img" src="image/15.jpg">
        <div class="caption center-align">
          <h3 class="black-text">This is our big Tagline!</h3>
          <h5 class="light black-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img class="responsive-img" src="image/7.jpg">
        <div class="caption left-align">
          <h3 class="black-text">Left Aligned Caption</h3>
          <h5 class="light black-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img class="responsive-img" src="image/18.jpg">
        <div class="caption right-align">
          <h3 class="black-text">Right Aligned Caption</h3>
          <h5 class="light black-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img class="responsive-img" src="image/20.jpg">
        <div class="caption center-align">
          <h3 class="black-text">This is our big Tagline!</h3>
          <h5 class="light black-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
    </ul>
  </div>  

  <nav class="teal">
      <div class="row container white">
        <div class="input-field col s12">
          <label for="search">Search</label>
          <input id="search" type="text">
        </div>
      </div>
  </nav>

  <div class="section"></div>

  <div class="row container white-text">
    <div class="col s12 m4 center teal">
      <i class="material-icons large">import_export</i>
      <h5>Style Korean - Made In Korea</h5>
      <p></p>
      <a href="#!" class="btn teal-text white waves-effect z-depth-5">Read More</a>
    </div>

    <div class="col s12 m4 center teal-text">
      <i class="material-icons large">shop</i>
      <h5>Belanja Kosmetik Dengan Harga Terjangkau</h5>
      <p></p>
      <a href="#!" class="btn teal waves-effect z-depth-5">Read More</a>
    </div>

    <div class="col s12 m4 center teal">
      <i class="material-icons large">location_on</i>
      <h5>Payakumbuh Prov.Sumatera Barat</h5>
      <p></p>
      <a href="#!" class="btn teal-text white waves-effect z-depth-5">Read More</a>
    </div>        
  </div>

<div class="row container">

<?php 
include './admin/koneksi.php';
$sql=mysqli_query($koneksi,"SELECT * FROM tb_produk ORDER BY tgl_post DESC");
while ($r=mysqli_fetch_array($sql)) { ?>

    <div class="col s12 m4 teal">
      <div class="card">
        <div class="card-image">
          <img class="responsive-img" src="./admin/img/<?php echo $r['foto']; ?>">
          <span class="card-title"><?php echo $r['produk']; ?></span>
          <p><?php echo $r['tgl_post']; ?></p>
        </div>
        <div class="card-content">
          <p><?php echo $r['deskripsi']; ?></p>
        </div>
        <div class="card-action">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>

<?php }
 ?>    

</div>



    <section class="section-follow white grey-text text-darken-4 center">
       <div class="row container">
    <h4 class="center grey-text">Social Media</h4>
    <div class="progress"><div class="determinate" style="width: 100%;"></div></div>
            <p>Follow us on social media for special offers</p>
            <a href="#">
              <i class="fab fa-skype fa-3x blue-text"></i>
            </a>
            <a href="#">
              <i class="fab fa-google-plus fa-3x red-text"></i>
            </a>
            <a href="#">
              <i class="fab fa-instagram fa-3x red-text text-accent-3"></i>
            </a>
            <a href="#">
              <i class="fab fa-whatsapp fa-3x light-green-text text-accent-3"></i>
            </a>
            <a href="#">
              <i class="fab fa-facebook fa-3x blue-text text-darken-4"></i>
            </a>
            <a href="#">
              <i class="fab fa-telegram fa-3x blue-text text-darken-3"></i>
            </a>
          </div>
      </div>
    </section>  

    <section id="gallery" class="section section-gallery scrollspy">
      <div class="container">
        <h5 class="center">
          <span class="teal-text">Photo</span> <span class="grey-text">Gallery</span>
          <div class="progress"><div class="determinate" style="width: 100%;"></div></div>
        </h5>
        <div class="row">
          <div class="col s12 m3">
            <img src="image/33.png" alt="" class="materialboxed responsive-img">
          </div>
          <div class="row">
          <div class="col s12 m3">
            <img src="image/32.png" alt="" class="materialboxed responsive-img">
          </div>
          <div class="row">
          <div class="col s12 m3">
            <img src="image/35.png" alt="" class="materialboxed responsive-img">
          </div>
          <div class="row">
          <div class="col s12 m3">
            <img src="image/34.png" alt="" class="materialboxed responsive-img">
          </div>
        </div>
      </div>
    </section>

  </div>