  <div class="row container">
    <h3 class="center teal-text">Produk</h3>
    <div class="progress"><div class="determinate" style="width: 100%;"></div></div>
<?php 
include './admin/koneksi.php';
$sql=mysqli_query($koneksi,"SELECT * FROM tb_produk ORDER BY tgl_post DESC");
while ($r=mysqli_fetch_array($sql)) { ?>

    <div class="col s12 m4 teal">
      <div class="card">
        <div class="card-image">
          <img class="responsive-img" src="./admin/img/<?php echo $r['foto']; ?>">
          <span class="card-title"><?php echo $r['produk']; ?></span>
          <p><?php echo $r['tgl_post']; ?></p>
        </div>
        <div class="card-content">
          <p><?php echo $r['deskripsi']; ?></p>
        </div>
        <div class="card-action">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>

<?php }
 ?>    
    </div>